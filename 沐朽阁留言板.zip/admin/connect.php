<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "apiadmin";
// 创建连接
@$db = new mysqli($servername, $username, $password, $dbname);
// 检测连接
if ($db->connect_error) {
    die("连接失败: " . $db->connect_error);
}else{
$db->query("set names utf8"); 
}
