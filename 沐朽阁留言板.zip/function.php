<?php
//跳转弹窗
function alert($tip, $url, $type = "jump") {
    $js = "<script>";
    if ($tip)
        $js .= "alert('" . $tip . "');";
    switch ($type) {
        case "jump" : //跳转
            if ($url)
                $js .= "window.location.href='" . $url . "';";
            break;
    }
    $js .= "</script>";
    echo $js;
    if ($type) {
        exit();
    }
}

//判断是否登录
function isLogin($url){
	session_start();
	if($_SESSION["login"]==1)
	{
		header("Location: ".$url);
	}
}