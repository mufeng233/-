<header class="mdui-appbar mdui-appbar-fixed">
  <div class="mdui-toolbar mdui-color-theme">
    <span class="mdui-btn mdui-btn-icon mdui-ripple mdui-ripple-white" mdui-drawer="{target: '#main-drawer', swipe: true}"><i class="mdui-icon material-icons">menu</i></span>
    <a href="./" class="mdui-typo-title">留言板</a>
    <div class="mdui-toolbar-spacer"></div>
  </div>
</header>

<div class="mdui-drawer" id="main-drawer">
  <div class="mdui-list" mdui-collapse="{accordion: true}" style="margin-bottom: 76px;">
          <div class="mdui-collapse-item">
        <div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
          <i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-blue">home</i>
          <a href="./" class="mdui-list-item-content">首页</a>
        </div>
        <div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
          <i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-pink">group</i>
          <a href="./login.php" class="mdui-list-item-content">登录</a>
        </div>
        <div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
          <i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-cyan">group_add</i>
          <a href="./reg.php" class="mdui-list-item-content">注册</a>
        </div>
        <div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
          <i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-yellow-600">exit_to_app</i>
          <a href="./post.php?type=exit_login" class="mdui-list-item-content">退出登录</a>
        </div>
      </div>
      </div>
</div>