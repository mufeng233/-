<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>沐朽阁留言板</title>
  <link rel="stylesheet" href="css/mdui.min.css"/>
  <link rel="stylesheet" type="text/css" href="./css/litewebchat.min.css" />
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-indigo mdui-theme-accent-pink mdui-theme-layout-auto">
<?php include "header.php";?>
<form action="post.php">
<?php
  session_start();
  if($_SESSION["login"]==1)
  {
  echo '
<div class="mdui-container">
  <h2 class="mdui-text-color-theme">发表留言</h2>
  <div class="mdui-card">
		<div class="mdui-container">
			<div class="mdui-textfield">
  				<textarea class="mdui-textfield-input" type="text" rows="4" name="content" maxlength="70" placeholder="请输入留言内容" required/></textarea>
  				<input class="mdui-hidden" name="type" value="comment" />
  				<div class="mdui-textfield-error">留言内容不能为空</div>
			</div>
		</div>
  </div>
  <br>
  <div class="mdui-typo">
	<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="sumbit"><i class="mdui-icon material-icons">check</i>发表</button>
  </div>
</div>';
  }else{
  echo '<div class="mdui-container">
  			<h2 class="mdui-text-color-theme">您还未登录，请先<a class="mdui-text-color-pink" href="./login.php">登陆</a></h2>
  		</div>';
  }
?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="lite-chatbox">
  			<div class="mdui-card mdui-color-white">
  				<div class="mdui-card-header">
  					<div class="mdui-card-header-avatar">
  						<i class="mdui-icon material-icons mdui-text-color-theme">chat</i>
  					</div>
  					<div class="mdui-card-header-title">
  						<span class="mdui-text-color-theme">留言内容：</span>
  					</div>
  				</div>
    			<div class="mdui-card-content">
    				<?php
    				include "function.php";
    				include "./admin/connect.php";
					$comment=$db->query("SELECT * FROM `mxglyb_content` order by 1 desc limit 10");
					$comment_all=$comment->fetch_all();
    				foreach($comment_all as $key => $value){
    					date_default_timezone_set("PRC");
    					$date=date("Y-m-d H-i-s", $value[6]);
    					echo '<div class="tips"><span>'.$date.'</span></div>';
    					echo '<div class="cleft cmsg"><img class="headIcon radius" ondragstart="return false;"  oncontextmenu="return false;"  src="http://q1.qlogo.cn/g?b=qq&nk='.$value[3].'&s=640" /><span class="name">';
    					if($value[5]==0){
    					}else if($value[5]==1){
    						echo '<span class="htitle admin">管理员</span>';
    					}else if($value[5]==2){
    						echo '<span class="htitle owner">板主</span>';
    					}
    					echo $value[1].'</span><span class="content">'.$value[2].'</span></div>';
    				}
    				?>
    			</div>
  			</div>
		</div>
	</div>
</div>
<br>
</form>
<script src="js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>