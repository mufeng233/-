<?php
//print_r($_REQUEST);
include "./admin/connect.php";
include "function.php";

$req = $_REQUEST;//获取请求内容

$type = $req["type"];//获取请求类型

if($req){
	if($type=="reg"){
		$name=$req["name"];
		$qq=$req["qq"];
		$password=$req["password"];
		$time=time();
		$select_user=$db->query("SELECT * FROM `mxglyb_user`");
		$select_all_user=$select_user->fetch_all();
		//print_r($select_all_user);
		foreach($select_all_user as $key => $value){
		if($value[1]==$name){
			alert("用户名已存在！", "./reg.php");
		}else{
			$reg_insert=$db->query("INSERT INTO `mxglyb_user` (`id`, `name`, `qq`, `password`, `admin`, `time`) VALUES (NULL, '{$name}', '{$qq}', '{$password}', '0', '{$time}');");
			alert("注册成功！正在跳转登录页面", "./login.php");
		}
		echo $value;
		}
	}else if($type=="login"){
		$name=$req["name"];
		$password=$req["password"];
		$select_user=$db->query("SELECT * FROM `mxglyb_user`");
		$select_all_user=$select_user->fetch_all();
		foreach($select_all_user as $key => $value){
			if($value[1]==$name&&$value[3]==$password)
			{
				session_start();
				$_SESSION["login"]=1;
				$_SESSION["name"]=$name;
				$_SESSION["qq"]=$value[2];
				$_SESSION["admin"]=$value[4];
				alert("登录成功！", "./");
			}else{
				alert("登录失败！用户名或密码错误", "./");
			}
		}
	}else if($type=="exit_login"){
		session_start();
		unset($_SESSION["login"]);
		unset($_SESSION["name"]);
		unset($_SESSION["qq"]);
		unset($_SESSION["admin"]);
		session_destroy();
		alert("已退出登录！", "./");
	}else if($type=="comment"){
		session_start();
		$content=$req["content"];
		$name=$_SESSION["name"];
		$qq=$_SESSION["qq"];
		$admin=$_SESSION["admin"];
		$time=time();
		$toComment=$db->query("INSERT INTO `mxglyb_content` (`id`, `name`, `content`, `qq`, `status`, `admin`, `time`) VALUES (NULL, '{$name}', '{$content}', '{$qq}', '0', '0', '{$time}');");
		if($toComment)
		{
			alert("评论成功！", "./");
		}else{
			alert("评论失败！", "./");
		}
	}
}else{
	header("location: ./");
}

