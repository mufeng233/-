<?php
include "../web_config.php";
include "../function.php";
isAdmin("../");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>修改页面 - <?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
		
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">修改页面</h2>
			</div>
			
			<?php
			if($_REQUEST["type"]&&$_REQUEST["id"]){
				if($_GET["type"]=="user"){
					$user=$db->query("SELECT * FROM `mxglyb_user` WHERE `id`=".$_GET['id']);
					$User=$user->fetch_assoc();
					if($User){
						echo '
					<form action="post.php" method="post">
						<div class="mdui-typo">
							<div class="mdui-title"><img class="mdui-img-circle" src="http://q2.qlogo.cn/headimg_dl?dst_uin='.$User['qq'].'&spec=640" style="width:40px;height:40px;"/> （注册时间：'. date("Y年m月d日", $User["time"]) .'）</div>
						</div>
						<div class="mdui-textfield">
							<label class="mdui-textfield-label">ID</label>
							<input class="mdui-textfield-input" type="number" value='.$User["id"].' disabled/>
						</div>
						<div class="mdui-textfield">
							<label class="mdui-textfield-label">用户名</label>
							<input class="mdui-textfield-input" type="text" value='.$User["name"].' name="name" required/>
						</div>
						<div class="mdui-textfield">
							<label class="mdui-textfield-label">QQ</label>
							<input class="mdui-textfield-input" type="number" value='.$User["qq"].' name="qq" required/>
						</div>
						<div class="mdui-textfield">
							<label class="mdui-textfield-label">密码</label>
							<input class="mdui-textfield-input" value='.$User["password"].' type="password" disabled/>
						</div>
						<div class="mdui-textfield">
							<label class="mdui-textfield-label">权限</label>
							<input class="mdui-textfield-input" type="number" value='.$User["admin"].' name="admin" required/>
							<div class="mdui-textfield-helper">0为普通用户，1为管理员(无实权)，2为板主(可进后台)</div>
						</div>
						<input class="mdui-hidden" name="type" value="edit_user" />
						<input class="mdui-hidden" name="id" value="'.$_REQUEST["id"].'" />
						<button class="mdui-btn mdui-ripple mdui-color-theme-accent mdui-float-right" type="submit">修改</button>
					</form>
						';
					}else if(!$User){
						echo '<div class="mdui-typo-display-4 mdui-text-center mdui-text-color-theme-accent">404</div><br><div class="mdui-typo-display-3 mdui-text-center mdui-text-color-theme-accent">Not Found</div>';
					}
				}
			}else{
				echo '<div class="mdui-typo-display-4 mdui-text-center mdui-text-color-theme-accent">404</div><br><div class="mdui-typo-display-3 mdui-text-center mdui-text-color-theme-accent">Not Found</div>';
			}
			?>
		</div>
		<br>
	</div>
</div>
<br>
<?php include "footer.php";?>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>