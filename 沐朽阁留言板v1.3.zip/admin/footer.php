<!--弹窗关于-->
	<div class="mdui-dialog" id="about">
    	<div class="mdui-dialog-title"><i class="mdui-icon material-icons mdui-text-color-theme-accent">remove_red_eye</i> 关于</div>
    	<div class="mdui-dialog-content">本留言板为沐风版权所有，最终解释权也归沐风所有<br>本留言板规定的留言内容：<a class="mdui-text-color-theme-accent" href="http://media.people.com.cn/GB/n1/2017/0825/c14677-29495044.html">查看详情</a><br>帮助：<u><a class="mdui-text-color-theme-accent" mdui-dialog="{target: '#help'}" mdui-dialog-close>查看详情</a></u></div>
    	<div class="mdui-dialog-actions">
      		<button class="mdui-btn mdui-color-theme-accent mdui-ripple" mdui-dialog-close>我知道了</button>
    	</div>
  </div>
<!--End-弹窗帮助-->
	
<!--弹窗关于-->
	<div class="mdui-dialog" id="help">
    	<div class="mdui-dialog-title"><i class="mdui-icon material-icons mdui-text-color-theme-accent">help_outline</i> 帮助</div>
    	<div class="mdui-dialog-content">留言板帮助：<br>[br]=>换行<br>[link]链接地址[/link]=>发送链接<br>留言内容自动屏蔽HTML标签<br>关于：<u><a class="mdui-text-color-theme-accent" mdui-dialog="{target: '#about'}" mdui-dialog-close>查看详情</div>
    	<div class="mdui-dialog-actions">
      		<button class="mdui-btn mdui-color-theme-accent mdui-ripple" mdui-dialog-close>我知道了</button>
    	</div>
  </div>
<!--End-弹窗帮助-->