<?php
session_start();
if($_SESSION["admin"]==2){
}else{
	header("Location: ../");
}
?>
<script type="text/javascript">
        function change_style() {
            $('body').toggleClass('mdui-theme-layout-dark');
        }
</script>
<header class="mdui-appbar mdui-appbar-scroll-hide mdui-appbar-fixed">
  <div class="mdui-toolbar mdui-color-white">
    <span class="mdui-btn mdui-btn-icon mdui-ripple mdui-ripple-white" mdui-drawer="{target: '#main-drawer', swipe: true}"><i class="mdui-icon material-icons">menu</i></span>
    <a href="./" class="mdui-typo-title"><?php echo $config['title'];?></a>
    <div class="mdui-toolbar-spacer"></div>
    <button mdui-tooltip="{content: '夜间模式', position: 'bottom'}" class="mdui-btn mdui-btn-icon" onclick="change_style()"><i class="mdui-icon material-icons">brightness_6</i></button>
    <button class="mdui-btn mdui-btn-icon mdui-ripple" mdui-menu="{target: '#menu'}"><i class="mdui-icon material-icons">more_vert</i></button>
    <!--菜单-->
    <ul class="mdui-menu" id="menu">
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" href="../">查看站点</a>
    	</li>
    	<li class="mdui-divider"></li>
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" mdui-dialog="{target: '#about'}">关于</a>
    	</li>
    	<li class="mdui-divider"></li>
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" mdui-dialog="{target: '#help'}">帮助</a>
    	</li>
	</ul>
	<!--End-菜单-->
	
	
  </div>
</header>



<div class="mdui-drawer" id="main-drawer">
	<div class="mdui-list" mdui-collapse="{accordion: true}" style="margin-bottom: 76px;">
		<div class="mdui-collapse-item">
			<div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-blue">home</i>
				<a href="./" class="mdui-list-item-content">后台首页</a>
			</div>
			<div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-orange">settings</i>
				<a href="webset.php" class="mdui-list-item-content">网站配置</a>
			</div>
			<div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-pink">group</i>
				<a href="user.php" class="mdui-list-item-content">用户列表</a>
			</div>
			<div class="mdui-collapse-item-header mdui-list-item mdui-ripple">
				<i class="mdui-list-item-icon mdui-icon material-icons mdui-text-color-yellow-600">comment</i>
				<a href="content.php" class="mdui-list-item-content">留言列表</a>
			</div>
		</div>
	</div>
</div>

