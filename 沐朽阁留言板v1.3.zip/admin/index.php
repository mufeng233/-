<?php
include "../web_config.php";
include "../function.php";
isAdmin("../");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title><?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
  <link rel="stylesheet" href="css/style.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
		
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">后台首页</h2>
			</div>
			<div class="mdui-col-xs-12 mdui-row-xs-2 mdui-grid-list">
				<div class="row">
          			<div class="col-md-6 col-xl-3">
            			<div class="card bg-info text-white">
              				<div class="card-body clearfix">
                				<div class="flex-box">
                 					<span class="img-avatar img-avatar-48 bg-translucent"><i class="mdui-icon material-icons">assessment</i></span>
                				</div>
                			<div class="mdui-text-right">访问次数：<?php echo $config['access'];?></div>
              			</div>
            		</div>
          		</div>
          		
          		<div class="row">
          			<div class="col-md-6 col-xl-3">
            			<div class="card bg-pink text-white">
              				<div class="card-body clearfix">
                				<div class="flex-box">
                 					<span class="img-avatar img-avatar-48 bg-translucent"><i class="mdui-icon material-icons">group</i></span>
                				</div>
                			<div class="mdui-text-right">用户总数：<?php echo $config['users'];?></div>
              			</div>
            		</div>
          		</div>
          		
          		<div class="row">
          			<div class="col-md-6 col-xl-3">
            			<div class="card bg-cyan text-white">
              				<div class="card-body clearfix">
                				<div class="flex-box">
                 					<span class="img-avatar img-avatar-48 bg-translucent"><i class="mdui-icon material-icons">comment</i></span>
                				</div>
                			<div class="mdui-text-right">留言总数：<?php echo $config['comment'];?></div>
              			</div>
            		</div>
          		</div>
          		
			</div>
		</div>
	</div>
</div>
<?php include "footer.php";?>
<script src="//cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<script>mdui.snackbar("欢迎回来～ ［<?php echo $_SESSION["name"];?>］");</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>