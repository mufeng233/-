<?php
include "connect.php";
include "../function.php";
isAdmin("../");
$req=$_REQUEST;

if($req){
	if($req["type"]=="edit_user"&&$req["id"]!=""){
		$edit_user=$db->query("UPDATE `mxglyb_user` SET `name` = '{$req['name']}', `qq` = '{$req['qq']}', `admin` = '{$req['admin']}' WHERE `mxglyb_user`.`id` = {$req['id']};");
		if($edit_user){
			go("user.php?suc=5");
		}else if(!$edit_user){
			go("user.php?err=6");
			//print_r($req);
		}
	}else if($req["type"]=="check_content"&&$req["id"]!=""){
		$check=$db->query("UPDATE `mxglyb_content` SET `status` = '1' WHERE `mxglyb_content`.`id` = {$req['id']};");
		if($check){
			go("content.php?suc=6");
		}else if(!$check){
			go("content.php?err=7");
		}
	}else if($req["type"]=="delete_content"&&$req["id"]!=""){
		$delete=$db->query("DELETE FROM `mxglyb_content` WHERE `mxglyb_content`.`id` = {$req['id']};");
		if($delete){
			go("content.php?suc=7");
		}else if(!$delete){
			go("content.php?err=8");
		}
	}else if($req["type"]=="delete_user"&&$req["id"]!=""){
		$Delete=$db->query("DELETE FROM `mxglyb_user` WHERE `mxglyb_user`.`id` = {$req['id']};");
		if($Delete){
			go("user.php?suc=7");
		}else if(!$Delete){
			go("user.php?err=8");
		}
	}else if($req["type"]=="set_webconfig"){
		$time=time();
		$set=$db->query("UPDATE `mxglyb_config` SET `title` = '{$req['title']}', `description` = '{$req['description']}', `keywords` = '{$req['keywords']}', `favicon` = '{$req['favicon']}', `author` = '{$req['author']}', `email` = '{$req['email']}', `copyright` = '{$req['copyright']}', `icp` = '{$req['icp']}', `time` = '{$time}' WHERE `mxglyb_config`.`id` = 1;");
		if($set){
			go("webset.php?suc=5");
		}else if(!$set){
			go("webset.php?err=6");
		}
	}else{
		go("../");
	}
}else{
	go("../");
}