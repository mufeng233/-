<?php
include "../web_config.php";
include "../function.php";
isAdmin("../");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>用户列表 - <?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
  <link rel="stylesheet" href="css/style.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
		
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">用户列表</h2>
			</div>
			
			<div class="mdui-table-fluid">
  				<table class="mdui-table">
    				<thead>
      					<tr>
        					<th>ID</th>
        					<th>用户名</th>
        					<th>QQ</th>
        					<th>权限</th>
        					<th>操作</th>
      					</tr>
    				</thead>
    				<tbody>
    					<?php
    					include "connect.php";
    					$select_user=$db->query("SELECT * FROM `mxglyb_user`");
    					$userAll=$select_user->fetch_all();
    					foreach($userAll as $k => $v){
    					echo '
      						<tr>
        						<td>'.$v[0].'</td>
        						<td>'.$v[1].'</td>
        						<td>'.$v[2].'</td>
        						<td>';
        				if($v[4]==0){
        					echo "成员";
        				}else if($v[4]==1){
        					echo "管理员";
        				}else if($v[4]==2){
        					echo "板主";
        				}else{
        					echo "获取失败";
        				}
        				echo '
        						</td>
        						<td><a class="mdui-btn mdui-btn-icon mdui-ripple mdui-shadow-1" href="edit.php?type=user&id='.$v[0].'"><i class="mdui-icon material-icons mdui-text-color-theme-accent">edit</i></a> <a class="mdui-btn mdui-btn-icon mdui-ripple mdui-shadow-1" href="post.php?type=delete_user&id='.$v[0].'"><i class="mdui-icon material-icons mdui-text-color-theme-accent">delete</i></a></td>
      						</tr>';
      					}
      					?>
      				</tbody>
  				</table>
			</div>
			
		</div>
		<br>
	</div>
</div>
<br>
<?php include "footer.php";?>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>