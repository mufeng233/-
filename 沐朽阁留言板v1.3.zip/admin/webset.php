<?php
include "../web_config.php";
include "../function.php";
isAdmin("../");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>网站配置 - <?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
  <link rel="stylesheet" href="css/style.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
		
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">网站配置</h2>
			</div>
			<form action="post.php" method="post">
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站标题</label>
					<input class="mdui-textfield-input" name="title" value="<?php echo $config['title'];?>" type="text" maxlength="10" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站简介</label>
					<input class="mdui-textfield-input" name="description" value="<?php echo $config['description'];?>" type="text" maxlength="50" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站关键词</label>
					<input class="mdui-textfield-input" name="keywords" value="<?php echo $config['keywords'];?>" type="text" maxlength="15" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站版权信息</label>
					<input class="mdui-textfield-input" name="copyright" value='<?php echo $config["copyright"];?>' type="text" required/>
					<div class="mdui-textfield-helper">可使用HTML标签</div>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站ICP备案信息</label>
					<input class="mdui-textfield-input" name="icp" value='<?php echo $config["icp"];?>' type="text" required/>
					<div class="mdui-textfield-helper">可使用HTML标签</div>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">网站头像</label>
					<input class="mdui-textfield-input" name="favicon" value="<?php echo $config['favicon'];?>" type="url" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">站长用户名</label>
					<input class="mdui-textfield-input" name="author" value="<?php echo $config['author'];?>" type="text" maxlength="8" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">站长邮箱</label>
					<input class="mdui-textfield-input" name="email" value="<?php echo $config['email'];?>" type="email" maxlength="20" required/>
			</div>
			<input class="mdui-hidden" name="type" value="set_webconfig" />
			<button class="mdui-btn mdui-ripple mdui-color-theme-accent mdui-float-right" type="submit">保存</button>
			
		</div>
		</form>
		<br>
	</div>
</div>
<br>
<?php include "footer.php";?>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>