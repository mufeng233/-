<?php

//判断是否登录 登录跳转
function isLogin($url){
	session_start();
	if($_SESSION["login"]==1)
	{
		header("Location: ".$url);
	}
}

//判断是否登录 未登录跳转
function ifLogin($url){
	session_start();
	if($_SESSION["login"]==1){
	}else{
		header("Location: ".$url);
	}
}

//判断是否为管理员
function isAdmin($url){
	session_start();
	if($_SESSION["admin"]==2){
	}else{
		header("Location: ".$url);
		exit();
	}
}

//错误snackbar
function go($url){
	header("Location: ".$url);
}

function errMsg($err){
	$errmsg=[
		"",
		"用户名或密码错误",
		"用户名已存在",
		"验证码错误",
		"用户未登录",
		"留言失败",
		"修改失败",
		"审核失败",
		"删除失败",
	];
	if($err&&$errmsg[$err])
	{
		echo '<script>mdui.snackbar("'.$errmsg[$err].'")</script>';
	}
}

//成功snackbar
function sucMsg($suc){
	$sucmsg=[
		"",
		"登录成功",
		"注册成功！请登录",
		"退出登陆成功",
		"留言成功！请等待审核",
		"修改成功",
		"审核成功",
		"删除成功",
	];
	if($suc&&$sucmsg[$suc])
	{
		echo '<script>mdui.snackbar("'.$sucmsg[$suc].'")</script>';
	}
}