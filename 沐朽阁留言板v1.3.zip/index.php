<?php include "web_config.php";?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title><?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">
  <link rel="icon" href="<?php echo $config['favicon'];?>" mce_href="<?php echo $config['favicon'];?>" type="image/x-icon">
  <link rel="shortcut icon" href="<?php echo $config['favicon'];?>" mce_href="<?php echo $config['favicon'];?>" type="image/x-icon">
  <link rel="stylesheet" href="css/mdui.min.css"/>
  <link rel="stylesheet" type="text/css" href="./css/litewebchat.min.css" />
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<form action="post.php" method="post">
<!--登录检测-->
<?php
  session_start();
  if($_SESSION["login"]==1)
  {
  echo '
<div class="mdui-container">
  <h2 class="mdui-text-color-theme-accent">发表留言 - 已登录为〈<a class="mdui-text-color-pink">'.$_SESSION["name"].'</a>〉</h2><h3 class="mdui-text-color-theme-accent"><a class="mdui-text-color-theme-accent" href="user">->前往个人中心</a>';
  if($_SESSION["admin"]==2){
  echo '<a class="mdui-text-color-theme-accent" href="admin">｜->前往后台管理</a></h3>';
  }
  echo '
  <div class="mdui-card">
		<div class="mdui-container">
			<div class="mdui-textfield">
  				<textarea class="mdui-textfield-input" type="text" rows="4" name="content" maxlength="150" placeholder="请输入留言内容" required/></textarea>
  				<input class="mdui-hidden" name="type" value="comment" />
  				<div class="mdui-textfield-error">留言内容不能为空</div>
			</div>
		</div>
  </div>
  <br>
  <div class="mdui-typo">
	<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="sumbit"><i class="mdui-icon material-icons">check</i>发表</button>
  </div>
</div>';
  }else{
  echo '<div class="mdui-container">
  			<h2 class="mdui-text-color-theme-accent">您还未登录，请先<a class="mdui-text-color-pink" href="./login.php">登陆</a></h2>
  		</div>';
  }
?>
<!--End-登录检测-->
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="lite-chatbox">
  			<div class="mdui-card mdui-color-white">
  				<div class="mdui-card-header">
  					<div class="">
  						<i class="mdui-icon material-icons mdui-text-color-pink">chat</i><span class="mdui-text-color-pink-600">留言板</span>
  					</div>
  				</div>
    			<div class="mdui-card-content">
    				<!--留言内容-->
    				<?php
    				include "function.php";
    				include "./admin/connect.php";
					$comment=$db->query("SELECT * FROM `mxglyb_content` order by 1 desc limit 10");
					$comment_all=$comment->fetch_all();
    				foreach($comment_all as $key => $value){
    					date_default_timezone_set("PRC");
    					$date=date("Y-m-d H:i:s", $value[6]);
    					if($value[4]==1){
    						echo '<div class="tips"><span>'.$date.'</span></div>';
    						if($_SESSION["name"]==$value[1]){
    							echo '<div class="cright cmsg">';
    						}else{
    							echo '<div class="cleft cmsg">';
    						}
    						echo '<img class="headIcon radius" ondragstart="return false;"  oncontextmenu="return false;"  src="http://q1.qlogo.cn/g?b=qq&nk='.$value[3].'&s=640" /><span class="name">';
    						if($value[5]==0){
    						}
    						else if($value[5]==1){
    							echo '<span class="htitle admin">admin</span>';
    						}else if($value[5]==2){
    							echo '<span class="htitle owner">owner</span>';
    						}
    						echo $value[1].'</span><span class="content">'.$value[2].'</span></div>';
    					}
    				}
    				?>
    				
    				<!--End-留言内容-->
    			</div>
  			</div>
		</div>
	</div>
</div>
<br>
</form>
<?php include "footer.php";?>
<script src="js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>