<?php
include "function.php";
include "web_config.php";
isLogin("./");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>登录 - <?php echo $config['title'];?></title>
  <link rel="stylesheet" href="css/mdui.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<div class="mdui-container doc-container">
	<form action="post.php" method="post">
	<h2 class="mdui-text-color-theme">登录</h2>
	<div class="mdui-card">
	<div class="mdui-container">
		<div class="mdui-textfield mdui-textfield-floating-label">
  			<label class="mdui-textfield-label">用户名</label>
  			<input class="mdui-textfield-input" name="name" type="text" required/>
  		<div class="mdui-textfield-error">用户名不能为空</div>
		</div>

		<div class="mdui-textfield mdui-textfield-floating-label">
  			<label class="mdui-textfield-label">密码</label>
  			<input class="mdui-textfield-input" name="password" type="password" pattern="^.*(?=.{6,})(?=.*[a-z]).*$" required/>
  			<div class="mdui-textfield-error">密码至少 6 位，且包含小写字母</div>
		</div>
		<input class="mdui-hidden" name="type" value="login"/>
	</div>
	</div>
	<br>
	<div class="mdui-typo">
		<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="submit"><i class="mdui-icon material-icons">check</i>立即登录！</button>
	</div>
	</form>
</div><br>
<?php include "footer.php";?>
<script src="js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<script>

</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>

