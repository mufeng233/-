-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2020-10-25 03:15:51
-- 服务器版本： 5.6.38
-- PHP 版本： 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `apiadmin`
--

-- --------------------------------------------------------

--
-- 表的结构 `mxglyb_config`
--

CREATE TABLE `mxglyb_config` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `favicon` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `copyright` varchar(255) NOT NULL,
  `icp` varchar(255) NOT NULL,
  `users` text NOT NULL,
  `access` text NOT NULL,
  `comments` text NOT NULL,
  `time` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `mxglyb_config`
--

INSERT INTO `mxglyb_config` (`id`, `title`, `description`, `keywords`, `favicon`, `author`, `email`, `copyright`, `icp`, `users`, `access`, `comments`, `time`) VALUES
(1, '沐朽阁留言板', '一个基于MDUI和LiteChat的留言板,快来留下你的足迹吧', '沐朽阁,留言板,mdui,litechat', 'https://muxiuge.cn/favicon.ico', '沐风', '2441260435@qq.com', 'Copyright© 2020 <a href=\"https://muxiuge.cn\">沐朽阁</a>', '京ICP <a href=\"https://beian.miit.gov.cn/\">备你妈的案</a>', '10', '10', '10', '1603591687');

-- --------------------------------------------------------

--
-- 表的结构 `mxglyb_content`
--

CREATE TABLE `mxglyb_content` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `qq` text NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `admin` int(10) NOT NULL DEFAULT '0',
  `time` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `mxglyb_user`
--

CREATE TABLE `mxglyb_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `qq` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` int(10) NOT NULL,
  `time` text NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '这个人很懒什么也没有留下'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `mxglyb_user`
--

INSERT INTO `mxglyb_user` (`id`, `name`, `qq`, `password`, `admin`, `time`, `description`) VALUES
(1, '沐风', '2441260435', 'a123456', 2, '1603019394', '这个人很懒什么也没有留下');

--
-- 转储表的索引
--

--
-- 表的索引 `mxglyb_config`
--
ALTER TABLE `mxglyb_config`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `mxglyb_content`
--
ALTER TABLE `mxglyb_content`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `mxglyb_user`
--
ALTER TABLE `mxglyb_user`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `mxglyb_config`
--
ALTER TABLE `mxglyb_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `mxglyb_content`
--
ALTER TABLE `mxglyb_content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- 使用表AUTO_INCREMENT `mxglyb_user`
--
ALTER TABLE `mxglyb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
