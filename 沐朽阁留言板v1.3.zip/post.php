<?php
//print_r($_REQUEST);
include "./admin/connect.php";
include "function.php";

$req = $_REQUEST;//获取请求内容

$type = $req["type"];//获取请求类型

if($req){
	if($type=="reg"){
		$name=$req["name"];
		$qq=$req["qq"];
		$password=$req["password"];
		$time=time();
		$select_user=$db->query("SELECT * FROM `mxglyb_user`");
		$select_all_user=$select_user->fetch_all();
		//print_r($select_all_user);
		foreach($select_all_user as $key => $value){
		if($value[1]==$name){
			//用户名已存在
			go("./reg.php?err=2");
			exit();
		}
		if($req["yzm"]!=1){
			//验证码错误
			go("./reg.php?err=3");
			exit();
		}
		}
		$reg_insert=$db->query("INSERT INTO `mxglyb_user` (`id`, `name`, `qq`, `password`, `admin`, `time`) VALUES (NULL, '{$name}', '{$qq}', '{$password}', '0', '{$time}');");
		//注册成功反应
		go("./login.php?suc=2");
		exit();
	}else if($type=="login"){
		$name=$req["name"];
		$password=$req["password"];
		$select_user=$db->query("SELECT * FROM `mxglyb_user`");
		$select_all_user=$select_user->fetch_all();
		foreach($select_all_user as $key => $value){
			if($value[1]==$name&&$value[3]==$password)
			{
				session_start();
				$_SESSION["login"]=1;
				$_SESSION["name"]=$name;
				$_SESSION["qq"]=$value[2];
				$_SESSION["admin"]=$value[4];
				//登录成功反应
				go("./index.php?suc=1");
				exit();
			}
		}
		//登录失败反应
		go("./login.php?err=1");
		exit();
	}else if($type=="exit_login"){
		session_start();
		if($_SESSION["login"]==1){
			unset($_SESSION["login"]);
			unset($_SESSION["name"]);
			unset($_SESSION["qq"]);
			unset($_SESSION["admin"]);
			session_destroy();
			//退出登陆反应
			go("./index.php?suc=3");
			exit();
		}else{
			//未登录，无法退出登陆
			go("./index.php?err=4");
			exit();
		}
	}else if($type=="comment"){
		session_start();
		$content=$req["content"];
		$replace=[
			"<"=>"",
			">"=>"",
			"[br]"=>"<br/>",
			"[link]"=>'<a href=\"\">',
			"[/link]"=>"<\/a>",
		];
		foreach($replace as $k => $v){
			$content=str_replace($k,$v,$content);
		}
		echo $content;
		$name=$_SESSION["name"];
		$qq=$_SESSION["qq"];
		$admin=$_SESSION["admin"];
		$time=time();
		$toComment=$db->query("INSERT INTO `mxglyb_content` (`id`, `name`, `content`, `qq`, `status`, `admin`, `time`) VALUES (NULL, '{$name}', '{$content}', '{$qq}', '0', '{$admin}', '{$time}');");
		if($toComment){
			go("./index.php?suc=4");
			exit();
		}else{
			go("./index.php?err=5");
			exit();
		}
	}
}else{
	header("location: ./");
}

