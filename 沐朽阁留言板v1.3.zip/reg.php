<?php
include "function.php";
include "web_config.php";
isLogin("./");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>注册 - <?php echo $config['title'];?></title>
  <link rel="stylesheet" href="css/mdui.min.css"/>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/materialdesignicons.min.css" rel="stylesheet">
  <link href="css/style.min.css" rel="stylesheet">
  <link href="js/imgver.min.css" rel="stylesheet">  
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<div class="mdui-container">
	<form action="post.php" method="post" id="form">
	<h3 class="mdui-text-color-theme">注册</h3>
	<div class="mdui-card">
	<div class="mdui-container">
		<div class="mdui-textfield mdui-textfield-floating-label">
  			<label class="mdui-textfield-label">用户名</label>
  			<input class="mdui-textfield-input" name="name" type="text" required/>
  		<div class="mdui-textfield-error">用户名不能为空</div>
	</div>

		<div class="mdui-textfield mdui-textfield-floating-label">
 	 		<label class="mdui-textfield-label">QQ</label>
  			<input class="mdui-textfield-input" name="qq" type="number" required/>
  			<div class="mdui-textfield-error">QQ格式错误</div>
		</div>

		<div class="mdui-textfield mdui-textfield-floating-label">
  			<label class="mdui-textfield-label">密码</label>
  			<input class="mdui-textfield-input" name="password" type="password" pattern="^.*(?=.{6,})(?=.*[a-z]).*$" required/>
  			<div class="mdui-textfield-error">密码至少 6 位，且包含小写字母</div>
		</div>
		<div class="mdui-textfield mdui-textfield-floating-label">
          <div id="imgVer" style="display:inline-block;"></div>
		</div>
		<div class="mdui-typo">
		<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="submit"><i class="mdui-icon material-icons">check</i>立即注册！</button>
		</div>
		<br><br>
		<input class="mdui-hidden" name="type" value="reg" type="text"/>
		<input class="mdui-hidden" id="yzm" name="yzm" value="" type="text"/>
	</div>
	</div><br>
	</form>
</div>
<?php include "footer.php";?>
<script src="js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.img.ver.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
    imgVer({
        el:'$("#imgVer")',
        width:'260',
        height:'116',
        img:[
            'images/img-slide-1.jpg',
            'images/img-slide-2.jpg',
            'images/img-slide-3.jpg',
            'images/img-slide-4.jpg',
            'images/img-slide-5.jpg',
        ],
        success:function () {
            // 在这里验证验证码
            // 验证码验证成功后执行登录
            var yzm = document.getElementById('yzm');
            if(yzm.value != 1){
            yzm.value=1;
            mdui.snackbar({
            	message: "验证成功！",
            	position: "top",
            });
            }else{
            mdui.snackbar({
				message: "你已经验证过了",
				position: "top"
            });
            }
        },
        error:function () {
            //alert('错误执行');
            
        }
    });
});
</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>

