<?php
include "../web_config.php";
include "../function.php";
ifLogin("../index.php?err=4");
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>修改信息 - <?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
			<?php
			include "../admin/connect.php";
			session_start();
			$name=$_SESSION["name"];
			$user=$db->query("SELECT * FROM `mxglyb_user` WHERE `name` = '{$name}';");
			$User=$user->fetch_assoc();
			?>
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">修改信息</h2>
			</div>
			<form action="post.php" method="post">
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">用户名</label>
					<input class="mdui-textfield-input" name="name" value="<?php echo $User['name'];?>" maxlength="10" type="text" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">QQ</label>
					<input class="mdui-textfield-input" name="qq" value="<?php echo $User['qq'];?>" maxlength="12" type="number" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">简介</label>
					<textarea class="mdui-textfield-input" name="description" type="text" row="4" maxlength="70" required><?php echo $User['description'];?></textarea>
			</div>
			<input class="mdui-hidden" name="type" value="edit_info" />
			<div class="mdui-typo">
				<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="submit">修改</button>
			</div>
			</form>
		</div><br>
	</div>
</div>
<?php include "footer.php";?>
<script src="//cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>