<?php
include "../web_config.php";
include "../function.php";
ifLogin("../index.php?err=4");
session_start();
?>
<!DOCTYPE html>
<html lang="zh-cmn-Hans">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
  <title>修改密码 - <?php echo $config['title'];?></title>
  <meta name="description" content="<?php echo $config['description'];?>">
  <meta name="keywords" content="<?php echo $config['keywords'];?>">
  <meta name="author" content="<?php echo $config['author'];?>">

  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/css/mdui.min.css"/>
</head>
<body class="mdui-drawer-body-left mdui-appbar-with-toolbar  mdui-theme-primary-white mdui-theme-accent-blue mdui-theme-layout-auto">
<?php include "header.php";?>
<br>
<div class="mdui-container">
	<div class="mdui-card mdui-ripple-white">
		<div class="mdui-container">
		
			<div class="mdui-title">
				<h2 class="mdui-text-color-theme-accent">修改密码</h2>
			</div>
			<form action="post.php" method="post">
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">旧密码</label>
					<input class="mdui-textfield-input" name="oldpwd" value="" type="password" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">新密码</label>
					<input class="mdui-textfield-input" name="newpwd" value="" type="password" required/>
			</div>
			<div class="mdui-textfield">
					<label class="mdui-textfield-label">再次输入密码</label>
					<input class="mdui-textfield-input" name="newpwd2" value="" type="password" required/>
			</div>
			<input class="mdui-hidden" name="type" value="edit_pwd" />
			<div class="mdui-typo">
				<button class="mdui-btn mdui-color-theme-accent mdui-ripple mdui-float-right" type="submit">修改</button>
			</div>
			</form>
		</div><br>
	</div>
</div>
<?php include "footer.php";?>
<script src="//cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/mdui@1.0.0/dist/js/mdui.min.js"></script>
<script>var $ = mdui.$;</script>
</script>
<?php
$err=$_GET["err"];
errMsg($err);
$suc=$_GET["suc"];
sucMsg($suc);
?>