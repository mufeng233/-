<script type="text/javascript">
        function change_style() {
            $('body').toggleClass('mdui-theme-layout-dark');
        }
</script>
<header class="mdui-appbar mdui-appbar-scroll-hide mdui-appbar-fixed">
  <div class="mdui-toolbar mdui-color-white">
    <a href="./" class="mdui-typo-title"><?php echo $config['title'];?></a>
    <div class="mdui-toolbar-spacer"></div>
    <button mdui-tooltip="{content: '夜间模式', position: 'bottom'}" class="mdui-btn mdui-btn-icon" onclick="change_style()"><i class="mdui-icon material-icons">brightness_6</i></button>
    <button class="mdui-btn mdui-btn-icon mdui-ripple" mdui-menu="{target: '#menu'}"><i class="mdui-icon material-icons">more_vert</i></button>
    <!--菜单-->
    <ul class="mdui-menu" id="menu">
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" href="../">回到主页</a>
    	</li>
    	<li class="mdui-divider"></li>
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" href="edit_pwd.php">修改密码</a>
    	</li>
    	<li class="mdui-divider"></li>
    	<li class="mdui-menu-item">
      		<a class="mdui-ripple" href="edit_info.php">修改信息</a>
    	</li>
	</ul>
	<!--End-菜单-->
  </div>
	
</header>
