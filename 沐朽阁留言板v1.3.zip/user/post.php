<?php
//print_r($_REQUEST);
include "../admin/connect.php";
include "../function.php";

$req=$_REQUEST;

if($req){
	if($req["type"]=="edit_pwd"){
		session_start();
		$oldpwd=$req["oldpwd"];
		$newpwd=$req["newpwd"];
		$newpwd2=$req["newpwd2"];
		$name=$_SESSION["name"];
		if($oldpwd!=$newpwd&&$newpwd==$newpwd2){
			$edit=$db->query("UPDATE `mxglyb_user` SET `password` = '$newpwd' WHERE `mxglyb_user`.`name` = '{$name}'");
		}
		if($edit){
			go("index.php?suc=5");
		}else{
			go("edit_pwd.php?err=6");
		}
	}else if($req["type"]=="edit_info"){
		session_start();
		$name=$req["name"];
		$qq=$req["qq"];
		$description=$req["description"];
		$Sname=$_SESSION["name"];
		if($name&&$qq&&$description&&$Sname){
			$edit=$db->query("UPDATE `mxglyb_user` SET `name` = '{$name}', `qq` = '{$qq}', `description` = '{$description}' WHERE `mxglyb_user`.`name` = '{$Sname}';");
		}
		if($edit){
			go("index.php?suc=5");
		}else{
			go("edit_info.php?err=6");
		}
	}else{
		header("location: ../");
	}
}else{
	header("location: ../");
}
