<?php
include "admin/connect.php";
$sql="SELECT * FROM `mxglyb_config`";
$webCfg=$db->query($sql);
$webCfg=$webCfg->fetch_assoc();
//print_r($webCfg);
$config=[
	"title"=>$webCfg["title"],
	"description"=>$webCfg["description"],
	"keywords"=>$webCfg["keywords"],
	"favicon"=>$webCfg["favicon"],
	"copyright"=>$webCfg["copyright"],
	"icp"=>$webCfg["icp"],
	"author"=>$webCfg["author"],
	"email"=>$webCfg["email"],
	"users"=>$webCfg["users"],
	"access"=>$webCfg["access"],
	"comment"=>$webCfg["comments"],
	"time"=>$webCfg["time"],
];